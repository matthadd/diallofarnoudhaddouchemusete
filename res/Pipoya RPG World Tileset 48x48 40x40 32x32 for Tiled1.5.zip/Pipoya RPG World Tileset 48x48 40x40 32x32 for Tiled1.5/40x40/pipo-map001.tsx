<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="pipo-map001" tilewidth="40" tileheight="40" tilecount="136" columns="8">
 <image source="pipo-map001.png" width="320" height="680"/>
 <wangsets>
  <wangset name="Big Mountain" type="corner" tile="32">
   <wangcolor name="" color="#ff0000" tile="32" probability="1"/>
   <wangtile tileid="32" wangid="0,0,0,1,0,0,0,0"/>
   <wangtile tileid="33" wangid="0,0,0,0,0,1,0,0"/>
   <wangtile tileid="34" wangid="0,1,0,0,0,1,0,0"/>
   <wangtile tileid="35" wangid="0,0,0,1,0,0,0,1"/>
   <wangtile tileid="40" wangid="0,1,0,0,0,0,0,0"/>
   <wangtile tileid="41" wangid="0,0,0,0,0,0,0,1"/>
   <wangtile tileid="42" wangid="0,0,0,1,0,0,0,1"/>
   <wangtile tileid="43" wangid="0,1,0,0,0,1,0,0"/>
  </wangset>
 </wangsets>
</tileset>
